import React from "react";

const Apps = () => {
  return <h1>Apps</h1>;
};

export default Apps;
